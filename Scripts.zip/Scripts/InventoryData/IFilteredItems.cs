using System.Collections.Generic;

namespace CreaXt.Inventory
{
    public interface IFilteredItems
    {
        public List<Item> GetItems();
    }
}
